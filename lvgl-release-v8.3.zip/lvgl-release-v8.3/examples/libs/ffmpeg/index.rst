Decode image
"""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/ffmpeg/lv_example_ffmpeg_1
  :language: c

Decode video
"""""""""""""""""""""""""""""""""""

.. lv_example:: libs/ffmpeg/lv_example_ffmpeg_2
  :language: c

